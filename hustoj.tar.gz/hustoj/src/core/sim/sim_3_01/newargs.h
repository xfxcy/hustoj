/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: newargs.h,v 2.4 2012-05-16 07:56:06 dick Exp $
*/

extern void get_new_std_input_args(int *argcp, char const **argvp[]);
extern void get_new_recursive_args(int *argcp, const char **argvp[]);
