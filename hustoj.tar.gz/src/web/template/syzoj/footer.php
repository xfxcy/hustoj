</div>
</div>
<script src="<?php echo $OJ_CDN_URL.$path_fix."template/$OJ_TEMPLATE"?>/css/semantic.min.js"></script>
<script src="<?php echo $OJ_CDN_URL.$path_fix."template/$OJ_TEMPLATE"?>/css/Chart.min.js"></script>
    <style>
    .footer {
        line-height: 1.4285em;
        font-family: "Lato", "Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft Yahei", "WenQuanYi Micro Hei", "Droid Sans Fallback", "sans-serif";
        box-sizing: inherit;
        padding: 0 !important;
        border: none !important;
        color: #888;
        font-size: 1rem;
        margin: 35px 0 14px !important;
        position: relative;
        width: 100%;
        bottom: 0;
        background: none transparent;
        border-radius: 0;
        box-shadow: none;
    }
    </style>
    <?php include(dirname(__FILE__)."/js.php");?>
    <div class="footer">
  <div class="ui center aligned container" style="display: flex; justify-content: center; align-items: center; gap: 20px;">
    
    <div>
      <?php echo $domain==$DOMAIN?$OJ_NAME:ucwords($OJ_NAME)."'s OJ"?> is Modified by 
      <a style="color: inherit !important;" title="GitHub"
        target="_blank" rel="noreferrer noopener" href="https://github.com/zhblue/hustoj">HUSTOJ</a> &
      <a style="color: inherit !important;" href="https://github.com/syzoj">SYZOJ</a>
    </div>

    <?php if ($OJ_BEIAN) { ?>
    <div style="display: flex; align-items: center; gap: 5px;">
      <img src="image/icp.png" alt="备案图标" style="height: 16px;">
      <a href="https://beian.miit.gov.cn/" style="text-decoration: none; color: #444444;" target="_blank">
        <?php echo $OJ_BEIAN; ?>
      </a>
    </div>
    <?php } ?>

  </div>
</div>

<?php if (isset($_SESSION[$OJ_NAME.'_user_id'])){ ?>
        <iframe id="sk" src="session.php" height=0px width=0px ></iframe>
<?php } ?>
<?php if (file_exists(dirname(__FILE__)."/css/$OJ_CSS")){ ?>
<link href="<?php echo $path_fix."template/$OJ_TEMPLATE"?>/css/<?php echo $OJ_CSS?>" rel="stylesheet">
<?php } ?>

</body>

</html>
